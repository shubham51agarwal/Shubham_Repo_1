package depositaccountapi;

public class BadRequestException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3700598661101742739L;

	public BadRequestException(String message) {
		super(message);
	}
	
}
