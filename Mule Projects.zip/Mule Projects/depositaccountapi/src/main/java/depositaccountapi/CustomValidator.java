package depositaccountapi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;
import org.mule.module.http.internal.ParameterMap;

public class CustomValidator implements Validator {

	@Override
	public ValidationResult validate(MuleEvent event) {
		ParameterMap x = event.getMessage().getInboundProperty("http.query.params");
		if(x.size()!=2)
		{
			return ImmutableValidationResult.error("Invalid query parameters please check");
		}
		String cDate = x.get("currentDate");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date currentDate = sdf.parse(cDate);
			Date newDate = sdf.parse(sdf.format(new Date()));
			if(!x.get("accountType").equals("deposit"))
			{
				return ImmutableValidationResult.error("Invalid Account Type Please check");
			}
			if (currentDate.compareTo(newDate)!=0) {
				return ImmutableValidationResult.error("Invalid current date please check");
			}
			else {
				event.getMessage().setOutboundProperty("currentDate", currentDate);
				Calendar c = Calendar.getInstance();
				c.setTime(currentDate);
				c.add(Calendar.DAY_OF_MONTH, 15);
				event.getMessage().setOutboundProperty("maturityDate", c.getTime());
				return ImmutableValidationResult.ok();
			}
		} catch (ParseException e) {
			return ImmutableValidationResult.error("Bad Request");
		}
		
		
	}

}
