package com.app.deposit.customexceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class DepositAccountException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2229152144664864919L;

	public DepositAccountException(String message) {
		super(message);
	}

}
