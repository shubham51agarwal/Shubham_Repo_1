
package com.app.deposit;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import com.app.deposit.customexceptions.BadRequestException;
import com.app.deposit.customexceptions.NoDataException;
import com.app.deposit.services.IDepositAccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * No description (Generated with springmvc-raml-parser v.2.0.3)
 * 
 */
@RestController
@RequestMapping(value = "", produces = "application/json")
@Validated
public class AccountController {

	@Autowired
	IDepositAccountService depositAccountService;

	/**
	 * Get All Deposit Accounts which are approching maturity date
	 * 
	 */
	@RequestMapping(value = "/api/v1/dda/accounts", method = RequestMethod.GET)
	public ResponseEntity<?> getDepositAccounts(@RequestParam String accountType,
			@RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date currentDate,
			@RequestHeader(name = "Accept", defaultValue = "application/json", required = false) String accept,
			HttpServletRequest request) {
		try {
			return depositAccountService.getAcc(accountType, currentDate);
		} catch (NoDataException ex) {
			return new CustomExceptionController().noContent(ex);
		} catch (BadRequestException badRequestException) {
			return new CustomExceptionController().badRequest(badRequestException);
		} catch (Exception exception) {
			return new CustomExceptionController().handleInternalError(exception);
		}
	}
}
