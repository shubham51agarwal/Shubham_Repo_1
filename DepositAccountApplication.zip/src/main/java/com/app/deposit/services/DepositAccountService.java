package com.app.deposit.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.deposit.SimpleRpcProducerRabbitApplication;
import com.app.deposit.model.DepositAccount;
import com.app.deposit.repositories.IDepositAccountRepository;
import com.app.deposit.model.Error;

@Service
public class DepositAccountService implements IDepositAccountService {

	private static final Logger logger = LogManager.getLogger(DepositAccountService.class);

	@Autowired
	IDepositAccountRepository depositAccountRepository;

	@Autowired
	SimpleRpcProducerRabbitApplication producer;

	@Override
	public ResponseEntity<?> getAcc(String accountType, Date currentDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String currentDateString = sdf.format(currentDate);
			String newDateString = sdf.format(new Date());
			if (accountType.equals("deposit") && newDateString.equals(currentDateString)) {
				Calendar c = Calendar.getInstance();
				c.setTime(currentDate);
				c.add(Calendar.DAY_OF_MONTH, 15);
				List<DepositAccount> list = depositAccountRepository.getAccounts(currentDate, c.getTime());
				producer.sendMessage(list);
				for (DepositAccount account : list) {
					logger.info(account.toString());
				}
				return new ResponseEntity<List<DepositAccount>>(list, HttpStatus.OK);
			} else {
				return new ResponseEntity<Error>(new Error("400", "Bad Request please check the query parameters"), HttpStatus.BAD_REQUEST);
			}
	}

}