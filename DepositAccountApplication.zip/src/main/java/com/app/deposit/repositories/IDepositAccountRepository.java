package com.app.deposit.repositories;

import java.util.Date;
import java.util.List;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.app.deposit.model.DepositAccount;

@Repository
public interface IDepositAccountRepository extends CrudRepository<DepositAccount, String>{

	@Query(value="SELECT ad.AccountDescriptorId , ad.AccountId ,ad.AccountType , a.AccountNumber, a.Nickname , "
				+ "a.InterestRate,d.BalanceAsOf , d.CurrentBalance , d.MaturityDate , ad.Status FROM shubham_stargate.depositaccount d "
				+ "inner join shubham_stargate.account a inner join shubham_stargate.accountdescriptor ad "
				+ "on d.RefAccountId = a.AccountMasterId and a.AccDescriptorId = ad.AccountDescriptorId "
				+ "where d.MaturityDate between :currentDate and :maturityDate",nativeQuery=true)
	public List<DepositAccount> getAccounts(@Param("currentDate") Date currentDate , @Param("maturityDate") Date maturityDate);

}
